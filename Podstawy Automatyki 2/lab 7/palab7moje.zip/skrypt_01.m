r = 1;

%k_3 = 8; %bez ekstrapolatora


%k_1 = 1000.0001; k_3 = 8; %tp = 0.01
%k_1 = 100.0034; k_3 = 7.75; %tp = 0.1
%k_1 = 10.02945; k_3 = 6.245; %tp = 1
%k_1 = 2; k_3 = 6.5; %tp = 5
%k_1 = 0.5; k_3 = 0.03445; %tp = 10

eks_1 = 1;
eks_2 = 1;

sim('tralala')

subplot(2,1,1)
plot(simout)

ylabel('odpowied�')
xlabel('czas [s]')

subplot(2,1,2)
plot(simout1)

ylabel('odpowied�')
xlabel('czas [s]')
legend('G_3(s)', 'G_2(s)', 'G_1(s)')