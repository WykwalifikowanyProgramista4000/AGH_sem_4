%k krytyczne dla trzeciego to 8

%tp=0.01;
%dla inercji III rzedu dalej 8
%k = 1000; dla in I rzedu


%tp=0.1;
%k=100.0035; - in I rzedu
%k=7.8; - in III rzedu

tp = 1;
%k = 6.25; - in III rzedu
%k=10.035;